import os
import telebot
import re
import requests
from dotenv import load_dotenv
load_dotenv()

URL = "https://api.groq.com/openai/v1/chat/completions"

BOT_TOKEN = os.getenv('TOKEN')
GROQ_API_KEY = "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"

def query_groq(prompt: str) -> str:
    try:
        headers = {
            "Authorization": f"Bearer {GROQ_API_KEY}",
            "Content-Type": "application/json"
        }

        data = {
            "model": "groq/compound-mini", 
            "messages": [
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": prompt}
            ]
        }

        response = requests.post(URL, headers=headers, json=data)
        response.raise_for_status()
        result = response.json()

        text = result['choices'][0]['message']['content']
        return text

    except Exception as e:
        return f"Ошибка при работе с Groq API: {e}"
    

try :
    if not BOT_TOKEN:
        print("TOKEN не найден, проверьте env.")
        exit()
    else:
        print("Бот запущен, работаем.")
except Exception as e:
    print(e)

bot = telebot.TeleBot(BOT_TOKEN)


def clean_html_for_telegram(html_text: str) -> str:
    """
    Оставляет только поддерживаемые Telegram HTML теги:
    <b>, <strong>, <i>, <em>, <u>, <a href="...">, <code>, <pre>
    Заменяет все <br>, <p>, <h*> и т.д. на перенос строки.
    """
    import re
    # Заменяем <br>, <p>, <h1>-<h6>, <div>, <span>, <li>, <ul>, <ol> на \n
    html_text = re.sub(r'</?(br|p|div|span|ul|li|ol|h[1-6])[^>]*>', '\n', html_text)
    # Можно оставить только разрешённые теги
    html_text = re.sub(r'</?(?!b|strong|i|em|u|a|code|pre)[^>]+>', '', html_text)
    return html_text



@bot.message_handler(commands=['compare'])
def compare_universities(message):
    try:
        text = message.text.replace("/compare", "").strip()
        if " vs " not in text and " VS " not in text:
            bot.reply_to(message, "Напиши команду в формате:\n/compare Университет1 vs Университет2")
            return

        text = text.replace(" VS ", " vs ")
        uni1, uni2 = [x.strip() for x in text.split(" vs ")]

        prompt = (
            f"Сравни два университета и предоставь красивое структурированное сравнение в формате Telegram, "
            f"с заголовками, пунктами и эмодзи:\n\n"
            f"1. {uni1}\n"
            f"2. {uni2}\n\n"
            "Включи: стоимость обучения, качество образования, репутацию, условия для студентов. "
            "Сделай красиво с эмодзи и нумерацией."
        )

        bot.reply_to(message, "Секунду, формирую красивое сравнение...")
        result = query_groq(prompt)
        bot.reply_to(message, result)

    except Exception as e:
        bot.reply_to(message, f"Произошла ошибка: {e}")



@bot.message_handler(commands=['about_university'])
def university_info(message):
    try:
        uni_name = message.text.replace("/about_university", "").strip()
        if not uni_name:
            bot.reply_to(
                message,
                "Напиши название университета после команды, например:\n/about_university KBTU"
            )
            return

        prompt = (
            f"Представь, что ты пишешь информационную карточку об университете для Telegram.\n"
            f"Университет: {uni_name}\n"
            f"Включи: миссию, историю, лидеров, достижения, известные проекты.\n"
            f"Сделай красиво: заголовки, эмодзи, списки.\n"
            f"Если такого университета не существует, ответь: 'Такого университета нет.'"
        )

        result = query_groq(prompt)
        if not result:
            bot.send_message(message.chat.id, "Не удалось получить данные об университете.")
            return

        cleaned_result = clean_html_for_telegram(result)

        bot.send_message(message.chat.id, cleaned_result, parse_mode="HTML")

    except Exception as e:
        bot.reply_to(message, f"Произошла ошибка: {e}")


@bot.message_handler(commands=['start'])
def start_comm(message): 
    bot.send_message(message.chat.id, "Здравствуйте, я ваш бот помощник по поиску университетов! Что будем искать?")


@bot.message_handler(commands=['help'])
def help_comm(message):
    bot.send_message(message.chat.id, "Я - бот с базой данных о любом университете Казахстана!")

@bot.message_handler(commands=['list_of_university'])
def handle_list_of_university(message):
    prompt = (
        "Составь список 15 университетов из разных городов Казахстана. "
        "Каждый пункт должен включать: название университета, город, краткую информацию о направлении обучения. "
        "Отформатируй красиво для Telegram с нумерацией и эмодзи."
    )
    
    result = query_groq(prompt)
    
    if not result:
        bot.reply_to(message, "Не удалось получить список университетов. Попробуйте позже.")
    else:
        
        for chunk in [result[i:i+4000] for i in range(0, len(result), 4000)]:
            bot.send_message(message.chat.id, chunk, parse_mode='HTML')


@bot.message_handler(commands=['programs'])
def handle_programs(message):
    university_name = message.text.replace("/programs", "").strip()
    if not university_name:
        bot.send_message(message.chat.id, "Напишите название университета после команды, например:\n/programs KBTU")
        return

    prompt = f"""
Составь подробный список академических программ для университета {university_name}.
Включи:
- Бакалавриат (направления, примерная стоимость)
- Магистратура (направления, примерная стоимость)
- Курсы и факультативы
Сделай красиво для Telegram в HTML с эмодзи и списками.
Если университета нет — напиши "Такого университета нет."
"""
    result = query_groq(prompt)
    if not result:
        bot.send_message(message.chat.id, "Не удалось получить данные о программах. Попробуйте позже.")
        return

    cleaned_result = clean_html_for_telegram(result)
    for chunk in [cleaned_result[i:i+4000] for i in range(0, len(cleaned_result), 4000)]:
        bot.send_message(message.chat.id, chunk, parse_mode='HTML')




@bot.message_handler(commands=['admission'])
def handle_admission(message):
    try:
        university_name = message.text.replace("/admission", "").strip()
        if not university_name:
            bot.send_message(
                message.chat.id, 
                "Напишите название университета после команды, например:\n/admission KBTU"
            )
            return

        prompt = f"""
Представь, что ты создаёшь информационную карточку о приёме и поступлении в университет для Telegram.  
Пользователь написал: {university_name}.  

Нужно создать ответ в следующем формате:  
- Сделать красивое оформление для Telegram с эмодзи, заголовками, нумерацией и списками.  
- Включить следующие разделы:

1️⃣ Требования к поступлению  
2️⃣ Процедуры подачи заявлений  
3️⃣ Сроки подачи  
4️⃣ Стипендии и финансовая помощь  
5️⃣ Советы для абитуриентов  

- Если университет не существует, ответь: "Такого университета нет."  
- Ответ должен быть подробным, как официальная инструкция по приёму.  
- Используй эмодзи, заголовки, списки, нумерацию для удобства чтения.
"""

        bot.send_message(message.chat.id, "Секунду, формирую информацию о приёме...")
        result = query_groq(prompt)

        if not result:
            bot.send_message(message.chat.id, "Не удалось получить информацию. Попробуйте позже.")
        else:
            for chunk in [result[i:i+4000] for i in range(0, len(result), 4000)]:
                bot.send_message(message.chat.id, chunk, parse_mode='HTML')

    except Exception as e:
        bot.reply_to(message, f"Произошла ошибка: {e}")




@bot.message_handler(commands=['international'])
def handle_international(message):
    try:
        university_name = message.text.replace("/international","").strip()
        if not university_name:
            bot.send_message(
                message.chat.id, 
                "Напишите название университета после команды, например:\n/international KBTU"
            )
            return

        prompt = (
            f"Представь, что ты пишешь информационную карточку для Telegram об университете: {university_name}.\n"
            "Опиши подробно международное сотрудничество: программы обмена, партнёрские университеты, "
            "стажировки за границей, возможности для иностранных студентов, стипендии, культурные программы.\n"
            "Сделай красиво: заголовки, эмодзи, списки. Если такого университета нет, ответь: 'Такого университета нет.'"
        )

        result = query_groq(prompt)
        cleaned_result = clean_html_for_telegram(result)

        for chunk in [cleaned_result[i:i+4000] for i in range(0, len(cleaned_result), 4000)]:
            bot.send_message(message.chat.id, chunk, parse_mode='HTML')

    except Exception as e:
        bot.reply_to(message, f"Произошла ошибка: {e}")




@bot.message_handler(commands=['tour'])
def university_3d_tour(message):
    try:
        university_name = message.text.replace("/tour", "").strip()
        if not university_name:
            bot.send_message(
                message.chat.id, 
                "Напишите название университета после команды, например:\n/tour KBTU"
            )
            return

        prompt = (
            f"Представь, что ты создаёшь виртуальный 3D-тур по университету для Telegram.\n"
            f"Университет: {university_name}\n"
            f"Опиши кампус, ключевые здания, аудитории, лаборатории, двор, общежития.\n"
            f"Если есть реальные ссылки на 3D туры или фотографии – упомяни их.\n"
            f"Если университета не существует – скажи: 'Такого университета нет.'\n"
            f"Если ты не умеешь создавать виртуальные 3D туры, честно напиши: 'Я не могу создать реальный 3D-тур, но могу описать кампус подробно.'\n"
            f"Сделай красиво с эмодзи, списками и структурой для Telegram."
        )

        bot.send_message(message.chat.id, "Готовлю 3D-тур, секунду...")
        result = query_groq(prompt)

        if not result:
            bot.send_message(message.chat.id, "Не удалось получить данные. Попробуйте позже.")
        else:
            cleaned_result = clean_html_for_telegram(result)
            for chunk in [result[i:i+4000] for i in range(0, len(result), 4000)]:
                bot.send_message(message.chat.id, chunk, parse_mode='HTML')

    except Exception as e:
        bot.send_message(message.chat.id, f"Произошла ошибка: {e}")


bot.polling(none_stop=True, skip_pending=True)