import os
import telebot
import requests
from dotenv import load_dotenv
load_dotenv()

URL = "https://api.groq.com/openai/v1/chat/completions"
TOKEN = os.getenv("TOKEN") 
GROQ_API_KEY = "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"

if not TOKEN or not GROQ_API_KEY:
    raise ValueError("TOKEN или GROQ_API_KEY не найдены в .env!")


bot = telebot.TeleBot(TOKEN)

def query_groq(prompt: str) -> str:
    try:
        headers = {
            "Authorization": f"Bearer {GROQ_API_KEY}",
            "Content-Type": "application/json"
        }

        data = {
            "model": "groq/compound-mini", 
            "messages": [
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": prompt}
            ]
        }

        response = requests.post(URL, headers=headers, json=data)
        response.raise_for_status()
        result = response.json()

        text = result['choices'][0]['message']['content']
        return text

    except Exception as e:
        return f"Ошибка при работе с Groq API: {e}"

@bot.message_handler(commands=['compare'])
def compare_universities(message):
    try:
        text = message.text.replace("/compare", "").strip()
        if " vs " not in text and " VS " not in text:
            bot.reply_to(message, "Напиши команду в формате:\n/compare Университет1 vs Университет2")
            return

        text = text.replace(" VS ", " vs ")
        uni1, uni2 = [x.strip() for x in text.split(" vs ")]

        prompt = (
            f"Сравни два университета:\n\n"
            f"1. {uni1}\n"
            f"2. {uni2}\n\n"
        )

        bot.reply_to(message, "Секунду, обрабатываю запрос...")
        result = query_groq(prompt)
        bot.reply_to(message, result)

    except Exception as e:
        bot.reply_to(message, f"Произошла ошибка: {e}")

if __name__ == "__main__":
    print("Бот запущен...")
    bot.polling(none_stop=True)